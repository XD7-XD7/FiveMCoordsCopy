# FiveM-CoordsSaver
Simple and useful! 

**Type /coords, and your coords will be copyed to your clipboard**
